<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

$_['heading_title']    = 'تحليلات جوجل';

// Text
$_['text_analytics']   = 'تحليلات جوجل';
$_['text_success']     = 'تم التعديل!';
$_['text_edit']        = 'تحرير';
$_['text_signup']      = 'قم بالدخول إلى <a href="http://www.google.com/analytics/" target="_blank"><u>موقع تحليلات جوجل</u></a> وأنشئ حساب لموقعك ثم انسخ كود تحليلات جوجل analytics code وألصقه في الحقل التالي أدناه.';
$_['text_default']     = 'الافتراضي';

// Entry
$_['entry_code']       = 'كود تحليلات جوجل - Google Analytics Code';
$_['entry_status']     = 'الحالة';

// Error
$_['error_permission'] = 'تحذير: أنت لا تمتلك صلاحيات التعديل!';
$_['error_code']	   = 'مطلوب!';
