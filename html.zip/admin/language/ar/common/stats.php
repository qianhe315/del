<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

$_['text_complete_status']   = 'طلبات مكتملة'; 
$_['text_processing_status'] = 'طلبات جارية'; 
$_['text_other_status']      = 'طلبات اخرى'; 