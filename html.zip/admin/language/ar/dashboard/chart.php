<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'الاحصائيات';

// Text
$_['text_order']                   = 'الطلبات';
$_['text_customer']                = 'العملاء';
$_['text_day']                     = 'اليوم';
$_['text_week']                    = 'هذا الاسبوع';
$_['text_month']                   = 'هذا الشهر';
$_['text_year']                    = 'هذا العام';