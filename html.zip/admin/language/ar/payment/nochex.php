<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']      = 'NOCHEX';

// Text
$_['text_payment']       = 'طرق الدفع';
$_['text_success']       = 'تم التعديل!';
$_['text_edit']          = 'تحرير';
$_['text_nochex']	     = '<a href="https://secure.nochex.com/apply/merchant_info.aspx?partner_id=172198798" target="_blank"><img src="view/image/payment/nochex.png" alt="NOCHEX" title="NOCHEX" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_seller']        = 'Seller / Personal Account';
$_['text_merchant']      = 'Merchant Account';

// Entry
$_['entry_email']        = 'البريد الالكتروني';
$_['entry_account']      = 'Account Type';
$_['entry_merchant']     = 'Merchant ID';
$_['entry_template']     = 'Pass Template';
$_['entry_test']         = 'وضع التجربة';
$_['entry_total']        = 'الاجمالي';
$_['entry_order_status'] = 'حالة الطلب';
$_['entry_geo_zone']     = 'المناطق الجغرافية';
$_['entry_status']       = 'الحالة';
$_['entry_sort_order']   = 'ترتيب الفرز';

// Help
$_['help_total']         = 'يجب أن تكون سلة الشراء تحتوي على هذا المبلغ لكي تظهر طريقة الدفع في صفحة إنهاء الطلب أو اتركه فارغ';

// Error
$_['error_permission']   = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';
$_['error_email']        = 'البريد الالكتروني مطلوب !';
$_['error_merchant']     = 'مطلوب !';