<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']     = 'تقرير نظام العمولة';

// Text
$_['text_list']         = 'قائمة';

// Column
$_['column_affiliate']  = 'اسم المشترك في النظام';
$_['column_email']      = 'البريد الالكتروني';
$_['column_status']     = 'الحالة';
$_['column_commission'] = 'العمولة';
$_['column_orders']     = 'عدد الطلبات';
$_['column_total']      = 'الاجمالي';
$_['column_action']     = 'تحرير';

// Entry
$_['entry_date_start']  = 'تاريخ البداية';
$_['entry_date_end']    = 'تاريخ النهاية';