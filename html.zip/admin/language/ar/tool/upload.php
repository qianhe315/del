<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']     = 'ملفات التنزيل';

// Text
$_['text_success']      = 'تم التعديل!';
$_['text_list']         = 'قائمة';

// Column
$_['column_name']       = 'اسم التنزيل';
$_['column_filename']   = 'اسم الملف';
$_['column_date_added'] = 'تاريخ الاضافة';
$_['column_action']     = 'تحرير';

// Entry
$_['entry_name']        = 'اسم التنزيل';
$_['entry_filename']    = 'اسم الملف';
$_['entry_date_added'] 	= 'تاريخ الاضافة';

// Error
$_['error_permission']  = 'تحذير : انت لا تمتلك صلاحيات التعديل !';